package com.example.eraksha;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set ActionBar title
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle("ERaksha");
        }

        statusText = findViewById(R.id.statusText);
        Button checkButton = findViewById(R.id.checkButton);
        Button sosButton = findViewById(R.id.sosButton);
        Button detectButton = findViewById(R.id.detectButton);

        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = "28.6139";
                String longitude = "77.2090";
                String currentDateAndTime = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault()).format(new Date());
                String riskFactor = "Very High";

                String status = "📍 Location: " + latitude + ", " + longitude + "\n" +
                        "🕒 Date & Time: " + currentDateAndTime + "\n" +
                        "⚠️ Risk Factor: " + riskFactor;

                statusText.setText(status);
            }
        });

        sosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // SOS message with coordinates and Google Maps link
                String subject = "🚨 SOS Alert from ERaksha";
                String message = "This is an emergency alert from the ERaksha app.\n\n" +
                        "📍 Location: 19.2678898, 72.96718877\n" +
                        "🕒 Date & Time: " + new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault()).format(new Date()) + "\n" +
                        "⚠️ Risk Factor: Very High\n\n" +
                        "Please take immediate action.\n\n" +
                        "Google Maps: https://www.google.com/maps?q=19.2678898,72.96718877";

                // Create an intent to send the email
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("message/rfc822"); // Set MIME type for email
                emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"21107001sanchitpatil@gmail.com"}); // Pre-fill email recipient
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject); // Pre-fill subject
                emailIntent.putExtra(Intent.EXTRA_TEXT, message); // Pre-fill message

                try {
                    // Start the email activity (user will send manually)
                    startActivity(Intent.createChooser(emailIntent, "Send SOS Email..."));
                } catch (android.content.ActivityNotFoundException ex) {
                    // No email client installed
                    statusText.setText("No email client installed. Please install an email app.");
                    ex.printStackTrace(); // Print stack trace for debugging
                }
            }
        });

        detectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                statusText.setText("CHECKING.........");

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        statusText.setText("DETECTING.........");
                    }
                }, 5000);
            }
        });
    }
}
